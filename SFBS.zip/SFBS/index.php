<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sports Facility Booking System</title>
    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f3f4f6;
            color: #333;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* Header Section */
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background-color: #0078D7;
            color: white;
        }

        .header-title {
            font-size: 24px;
            font-weight: bold;
        }

        .header-buttons {
            display: flex;
            gap: 10px;
        }

        .header-buttons button {
            padding: 8px 16px;
            font-size: 14px;
            font-weight: bold;
            color: #0078D7;
            background-color: white;
            border: 2px solid white;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s;
        }

        .header-buttons button:hover {
            background-color: #005EA6;
            color: white;
            border-color: white;
        }

        /* Main Section */
        main {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            text-align: center;
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 1000px;
            width: 100%;
        }

        .container img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
        }

        .container h1 {
            font-size: 28px;
            margin-bottom: 20px;
            color: #0078D7;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="header-title"></div>
        <div class="header-buttons">
            <button onclick="location.href='login.php'">Login</button>
            <button onclick="location.href='signup.php'">Signup</button>
            
        </div>
    </header>

    <!-- Main Content -->
    <main>
        <div class="container">
            <h1>Welcome to the Sports Facility Booking System</h1>
            <img src="pic1.jpg" alt="Sports Facility">
        </div>
    </main>
</body>
</html>
