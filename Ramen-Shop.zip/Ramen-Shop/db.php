<?php
$conn = mysqli_connect("localhost", "root", "", "ramen_shop");

if (!$conn) {
    die("Database connection failed");
}
?>
